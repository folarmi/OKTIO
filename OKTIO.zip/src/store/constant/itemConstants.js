export const GET_PROJECTS_REQUEST = "[Items Action] Get Items Request";
export const GET_PROJECTS = "[Items Action] Get Items";
export const GET_PROJECTS_FAIL = "[Items Action] Get Items Fail";
export const CONFIRMED_GET_PROJECTS = "[Items Action] Confirmed Get Items";
export const ADD_FIRST_FORM = "[Items Action] Add First Form";
export const PROJECTS_ADD_REQUEST = "[Items Action] Add First Form Request";
export const ADD_SECOND_FORM = "[Items Action] Add Second Form Request";