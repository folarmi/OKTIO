export const GET_PROJECTS_REQUEST = "[Projects Action] Get Projects Request";
export const GET_PROJECTS = "[Projects Action] Get Projects";
export const GET_PROJECTS_FAIL = "[Projects Action] Get Projects Fail";
export const CONFIRMED_GET_PROJECTS = "[Projects Action] Confirmed Get Projects";
export const ADD_FIRST_FORM = "[Projects Action] Add First Form";
export const PROJECTS_ADD_REQUEST = "[Projects Action] Add First Form Request";
export const ADD_SECOND_FORM = "[Projects Action] Add Second Form Request";